#ifndef DROPSHADOWEFFECT_H
#define DROPSHADOWEFFECT_H


class DropShadowEffect
{
public:
  DropShadowEffect();
};

#endif // DROPSHADOWEFFECT_H