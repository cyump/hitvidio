#include "dropshadoweffect.h"

DropShadowEffect::DropShadowEffect() {

}
